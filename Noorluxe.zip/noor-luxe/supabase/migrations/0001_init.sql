-- Noor Luxe initial schema. UNTESTED: run in Supabase SQL Editor, then test RLS with a non-admin user.
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text, phone text, country text check (country in ('PK','AE','SA')),
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);
create table public.categories (slug text primary key, name text not null);
create table public.products (
  slug text primary key, name text not null, category text not null references public.categories(slug),
  price_pkr integer not null check (price_pkr >= 0), color text, sizes text[] not null default '{}',
  description text, stock integer not null default 0 check (stock >= 0), badge text, active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.wishlists (
  user_id uuid references auth.users(id) on delete cascade,
  product_slug text references public.products(slug) on delete cascade,
  primary key (user_id, product_slug)
);
create table public.addresses (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  line1 text not null, city text not null, country text not null check (country in ('PK','AE','SA')), phone text
);
create table public.orders (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id),
  status text not null default 'pending' check (status in ('pending','paid','shipped','delivered','cancelled')),
  currency text not null check (currency in ('PKR','AED','SAR')), total_minor integer not null, payment_ref text,
  created_at timestamptz not null default now()
);
create table public.order_items (
  id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade,
  product_slug text not null references public.products(slug), size text,
  qty integer not null check (qty > 0), unit_price_pkr integer not null
);
create table public.newsletter (email text primary key, created_at timestamptz not null default now());

create function public.is_admin() returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin') $$;

create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as
$$ begin insert into public.profiles (id) values (new.id); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.wishlists enable row level security;
alter table public.addresses enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.newsletter enable row level security;

create policy "own profile read" on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy "own profile update" on public.profiles for update using (id = auth.uid())
  with check (id = auth.uid() and role = (select role from public.profiles where id = auth.uid()));
create policy "public read categories" on public.categories for select using (true);
create policy "public read active products" on public.products for select using (active or public.is_admin());
create policy "admin write categories" on public.categories for all using (public.is_admin()) with check (public.is_admin());
create policy "admin write products" on public.products for all using (public.is_admin()) with check (public.is_admin());
create policy "own wishlist" on public.wishlists for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own addresses" on public.addresses for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own orders read" on public.orders for select using (user_id = auth.uid() or public.is_admin());
create policy "admin update orders" on public.orders for update using (public.is_admin());
create policy "own order items read" on public.order_items for select
  using (exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin())));
-- No client insert policy on orders/order_items/newsletter: create them from server routes only (service role, never in the browser).
