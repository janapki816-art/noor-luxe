# Image files Noor Luxe expects (none are included yet)
Missing files show a fallback tile; nothing breaks. Use only images you have the right to use commercially (your own shoot, a purchased licence, or a free-licence site whose licence you have read for EACH image). Adult models only. Do not imply a famous brand unless the product truly is that brand.

## Hero (highest priority)
`public/images/hero-model.jpg` - adult female model, elegant luxury outfit, dark/charcoal background, warm gold light. Portrait 2000x2500 px or larger, model centred and head about 15-25% from the top, under ~400 KB after compression. Text sits at the bottom on phones and at the left on desktop, so keep those areas calm.

## Editorial category banners (3:4, ~1200x1600)
`public/images/editorial/<category-slug>.jpg` for: womens-fashion, mens-fashion, shoes, bags-accessories, watches-jewellery, beauty-lifestyle, electronics, home-living

## Product photos (4:5, ~1200x1500)
`public/images/products/<product-slug>-1.jpg`, `-2.jpg`, `-3.jpg` (front, detail, alternate angle) for every slug listed in `lib/products.ts`.
