# Noor Luxe

Next.js 15 + TypeScript + Tailwind CSS 3.

**Status: scaffold written, NOT yet installed, built or run.** The author environment had no internet, so `npm install` and `npm run dev` have never been executed. Run the steps below and report any errors.

## Mobile workflow (Android, browser only)
1. Create a free account at github.com and a new **private** repository named `noor-luxe`.
2. Unzip `noor-luxe.zip` on your phone. In the repo tap **Add file > Upload files**, upload the contents (keep folders; hidden `.claude` and `.gitignore` may need a file manager that shows hidden files), then **Commit changes**.
3. Tap **Code > Codespaces > Create codespace on main**. It opens VS Code in your browser (switch Chrome to "Desktop site" for a usable layout).
4. In the Codespace terminal run, one at a time:
   - `npm install`
   - `npm run lint` (TypeScript check)
   - `npm run dev`
5. Tap **Open in Browser** on the "port 3000" popup.
6. Copy `.env.example` to `.env.local` (`cp .env.example .env.local`) and fill in values. Never commit it.

## Supabase (needed only for real accounts)
1. supabase.com > New project. Put Project URL and anon key in `.env.local`.
2. SQL Editor > paste `supabase/migrations/0001_init.sql` > Run.
3. Authentication: enable email confirmation; set your site URL.
4. To make yourself admin, after registering run: `update public.profiles set role = 'admin' where id = '<your user id>';`
5. Test the policies with a non-admin account before trusting them.

## AI assistant
`/api/assistant` runs on the server. With `ANTHROPIC_API_KEY` set it asks the model using only catalogue data; without it, it falls back to basic keyword matching. It never adds to the cart: the customer taps Add.

## Built (untested)
Home, shop with search/filter/sort, category pages, product pages, cart and wishlist (browser storage), PKR/AED/SAR display, register/login/reset forms (need Supabase keys), account page, draft info pages, assistant route.

## NOT built
Checkout, payments, order tracking, shipping and tax rules, admin dashboard and management pages, order history, address management, newsletter backend, reviews, sitemap/robots, product images/gallery. Products are sample data in `lib/products.ts` and are not yet read from Supabase. Exchange rates are placeholders.
