---
name: ecommerce-security
description: Security checklist for auth, cart, checkout, payments, orders and admin pages. Use before writing or reviewing any of them.
---
# E-commerce security checklist
- Secrets: service-role keys, AI keys, payment secrets only in server env vars; only NEXT_PUBLIC_* values reach the browser. Never commit .env files.
- Supabase: RLS enabled on every table; customers read/write only their own rows (auth.uid()); admin role checked server-side, never from client state; test policies with a non-admin user.
- Prices: compute totals, shipping, tax and stock checks on the server from DB prices; never trust client-sent amounts.
- Payments: provider sandbox until real merchant credentials exist; mark an order paid only after server-side verification (webhook signature or provider API check); make webhooks idempotent.
- Input: validate every form and API body with a schema (zod); escape output; parameterized queries only.
- Web: CSRF-safe mutations, secure httpOnly cookies, rate-limit login/reset/AI-chat endpoints, security headers (CSP, frame protection, nosniff), no sensitive data in logs.
- AI assistant: server-side only; recommend from DB products; add to cart only after explicit user confirmation.
