---
name: noor-luxe-design-system
description: Noor Luxe visual rules. Use when building or styling any page, component, hero, product card, menu or animation for the Noor Luxe shop.
---
# Noor Luxe design system
Reference: dark cinematic campaign look (near-black, gold eyebrow labels, huge serif headlines with an italic gold last line, gold light-pool on a dark floor, full-screen scenes with slow cross-fades).
- Colors (CSS variables): --black #0A0A0B, --charcoal #16161A, --gold #C9A45C (champagne), --ivory #F3EBDD. Gold is an accent, never body text on large areas.
- Type: high-contrast serif for display (Cormorant Garamond or similar open license), clean sans for body (Inter). Eyebrows: 11-12px, uppercase, 0.2em tracking, gold.
- Buttons: outlined gold, 0-2px radius, uppercase small text; hover fills gold with black text.
- Motion: slow (600-1200ms) fades/parallax; MUST respect prefers-reduced-motion; no layout shift; animate transform/opacity only.
- Layout: generous spacing, one idea per screen, mobile-first (360px up), no horizontal overflow.
- Never use a plain white product grid as the first screen. Images: only licensed/own, always with alt text and next/image sizing.
