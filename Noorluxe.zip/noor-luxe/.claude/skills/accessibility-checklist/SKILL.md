---
name: accessibility-checklist
description: Accessibility and responsive checks for UI work. Use when finishing any page or component.
---
# Accessibility checklist
- Contrast: body text >= 4.5:1 (check gold on black); visible focus ring on every interactive element.
- Keyboard: full navigation by Tab; menus and dialogs trap/restore focus; Esc closes.
- Semantics: one h1 per page, landmarks (header/nav/main/footer), real buttons/links, labels tied to inputs, errors announced (aria-live).
- Images: meaningful alt text; decorative images alt="".
- Motion: honor prefers-reduced-motion; no autoplay audio.
- Responsive: test 360, 768, 1280, 1920px; touch targets >= 44px; no horizontal scroll.
