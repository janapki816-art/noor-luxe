"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useShop, type Currency } from "@/lib/shop";

const nav = [
  { href: "/", label: "Home" }, { href: "/category/womens-fashion", label: "Women" }, { href: "/category/mens-fashion", label: "Men" },
  { href: "/category/shoes", label: "Shoes" }, { href: "/category/bags-accessories", label: "Bags & Accessories" },
  { href: "/category/watches-jewellery", label: "Watches" }, { href: "/category/beauty-lifestyle", label: "Beauty & Lifestyle" },
];
const more = [{ href: "/category/electronics", label: "Electronics" }, { href: "/category/home-living", label: "Home & Living" }, { href: "/shop", label: "Shop All" }];
const I = { fill: "none", stroke: "currentColor", strokeWidth: 1.4, viewBox: "0 0 24 24", width: 20, height: 20, "aria-hidden": true } as const;

export default function Header() {
  const [open, setOpen] = useState(false);
  const { cartCount, wishlist, currency, setCurrency } = useShop();
  useEffect(() => { document.body.style.overflow = open ? "hidden" : ""; const k = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false); window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k); }, [open]);
  const ic = "relative flex min-h-[44px] min-w-[40px] items-center justify-center text-ivory hover:text-gold";
  const badge = (n: number) => n > 0 && <span className="absolute right-0 top-1.5 grid h-4 min-w-4 place-items-center bg-gold px-1 text-[9px] font-medium text-ink">{n}</span>;
  return (
    <header className="fixed inset-x-0 top-0 z-30 flex items-center justify-between bg-gradient-to-b from-ink via-ink/70 to-transparent px-4 pb-4 pt-[calc(env(safe-area-inset-top,0px)+8px)] md:px-10">
      <div className="flex items-center gap-1">
        <button className={`${ic} lg:hidden`} aria-label="Open menu" aria-expanded={open} aria-controls="drawer" onClick={() => setOpen(true)}>
          <svg {...I}><path d="M4 8h16M4 16h16" /></svg>
        </button>
        <Link href="/" className="whitespace-nowrap text-[12px] font-medium uppercase tracking-[.4em]" aria-label="Noor Luxe home"><span className="text-gold">◆ </span>Noor Luxe</Link>
      </div>
      <nav aria-label="Primary" className="hidden items-center gap-5 text-[11px] uppercase tracking-[.16em] text-ivory/75 lg:flex">
        {nav.map((l) => <Link key={l.href} href={l.href} className="hover:text-gold">{l.label}</Link>)}
      </nav>
      <div className="flex items-center">
        <Link href="/shop" aria-label="Search" className={ic}><svg {...I}><circle cx="11" cy="11" r="6.5" /><path d="m16 16 4 4" /></svg></Link>
        <Link href="/login" aria-label="Account" className={`${ic} hidden sm:flex`}><svg {...I}><circle cx="12" cy="8" r="3.8" /><path d="M5 20c1-4 4-5.5 7-5.5s6 1.5 7 5.5" /></svg></Link>
        <Link href="/wishlist" aria-label={`Wishlist, ${wishlist.length} items`} className={ic}><svg {...I}><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.6-7 10-7 10z" /></svg>{badge(wishlist.length)}</Link>
        <Link href="/cart" aria-label={`Shopping bag, ${cartCount} items`} className={ic}><svg {...I}><path d="M5 8h14l-1 12H6zM9 8V6a3 3 0 0 1 6 0v2" /></svg>{badge(cartCount)}</Link>
      </div>
      <div className={`fixed inset-0 z-40 ${open ? "" : "pointer-events-none"}`} aria-hidden={!open}>
        <div onClick={() => setOpen(false)} className={`absolute inset-0 bg-black/70 transition-opacity duration-500 ${open ? "opacity-100" : "opacity-0"}`} />
        <aside id="drawer" role="dialog" aria-modal="true" aria-label="Menu" className={`absolute inset-y-0 left-0 flex w-[84vw] max-w-sm flex-col bg-ink p-6 pt-[calc(env(safe-area-inset-top,0px)+16px)] transition-transform duration-500 ${open ? "translate-x-0" : "-translate-x-full invisible"}`}>
          <div className="flex items-center justify-between"><span className="eyebrow">Menu</span>
            <button aria-label="Close menu" className="flex min-h-[44px] min-w-[44px] items-center justify-center" onClick={() => setOpen(false)}><svg {...I}><path d="M6 6l12 12M18 6 6 18" /></svg></button></div>
          <nav className="mt-4 flex flex-col overflow-y-auto" aria-label="Mobile">
            {[...nav, ...more, { href: "/login", label: "Account" }].map((l) => <Link key={l.href + l.label} href={l.href} onClick={() => setOpen(false)} className="border-b border-gold/20 py-3 font-serif text-2xl hover:text-gold">{l.label}</Link>)}
          </nav>
          <div className="mt-auto pt-6"><label htmlFor="cur" className="eyebrow">Currency (display only)</label>
            <select id="cur" value={currency} onChange={(e) => setCurrency(e.target.value as Currency)} className="field mt-1">{(["PKR", "AED", "SAR"] as Currency[]).map((c) => <option key={c}>{c}</option>)}</select></div>
        </aside>
      </div>
    </header>
  );
}
