"use client";
import Image from "next/image";
import { useState } from "react";

/** Next/Image that falls back to an elegant tile if the file is missing or fails to load. Parent must be `relative` with a set aspect ratio. */
export default function SafeImage({ src, alt, sizes, priority = false, className = "", label = "Photograph coming soon" }:
  { src?: string; alt: string; sizes: string; priority?: boolean; className?: string; label?: string }) {
  const [bad, setBad] = useState(false);
  if (!src || bad) {
    return <div role="img" aria-label={alt} className="absolute inset-0 grid place-items-center bg-[radial-gradient(circle_at_50%_35%,#3a2f3d,#101014_70%)] px-3 text-center font-serif text-sm italic text-muted">{label}</div>;
  }
  return <Image src={src} alt={alt} fill sizes={sizes} priority={priority} loading={priority ? undefined : "lazy"} onError={() => setBad(true)} className={`object-cover ${className}`} />;
}
