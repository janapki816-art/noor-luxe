"use client";
import { useState } from "react";
import { useShop } from "@/lib/shop";
import { variantLabel, type Product } from "@/lib/products";

export default function AddToCart({ p }: { p: Product }) {
  const { addToCart, toggleWish, wishlist } = useShop();
  const [size, setSize] = useState(p.sizes[0]);
  const [color, setColor] = useState(p.colors[0]);
  const [done, setDone] = useState(false);
  return (
    <div className="mt-6">
      <div className="grid max-w-sm grid-cols-2 gap-3">
        <div><label htmlFor="co" className="eyebrow">Colour</label><select id="co" value={color} onChange={(e) => setColor(e.target.value)} className="field mt-1">{p.colors.map((c) => <option key={c}>{c}</option>)}</select></div>
        <div><label htmlFor="sz" className="eyebrow">Size</label><select id="sz" value={size} onChange={(e) => setSize(e.target.value)} className="field mt-1">{p.sizes.map((s) => <option key={s}>{s}</option>)}</select></div>
      </div>
      <div className="mt-5 flex flex-wrap gap-3">
        <button className="btn" disabled={p.stock < 1} onClick={() => { addToCart(p.slug, variantLabel(p, color, size)); setDone(true); }}>{p.stock < 1 ? "Sold out" : "Add to bag"}</button>
        <button className="btn" aria-pressed={wishlist.includes(p.slug)} onClick={() => toggleWish(p.slug)}>{wishlist.includes(p.slug) ? "Saved ♥" : "Save ♡"}</button>
      </div>
      <p role="status" aria-live="polite" className="mt-3 min-h-[22px] text-sm text-gold">{done ? "Added to your bag." : ""}</p>
    </div>
  );
}
