"use client";
import { useMemo, useState } from "react";
import ProductCard from "./ProductCard";
import { categories, type Product } from "@/lib/products";

export default function ProductBrowser({ items, lockCategory = false, initialQuery = "" }: { items: Product[]; lockCategory?: boolean; initialQuery?: string }) {
  const [q, setQ] = useState(initialQuery);
  const [cat, setCat] = useState("all");
  const [max, setMax] = useState(0);
  const [sort, setSort] = useState("featured");
  const list = useMemo(() => {
    let r = items.filter((p) => (lockCategory || cat === "all" || p.category === cat) && (!max || p.pricePKR <= max) &&
      (`${p.name} ${p.description} ${p.colors.join(" ")} ${p.brand}`).toLowerCase().includes(q.trim().toLowerCase()));
    if (sort === "low") r = [...r].sort((a, b) => a.pricePKR - b.pricePKR);
    if (sort === "high") r = [...r].sort((a, b) => b.pricePKR - a.pricePKR);
    return r;
  }, [items, q, cat, max, sort, lockCategory]);
  return (
    <div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div><label htmlFor="q" className="eyebrow">Search</label><input id="q" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Gown, watch, candle…" className="field mt-1" /></div>
        {!lockCategory && <div><label htmlFor="c" className="eyebrow">Category</label><select id="c" value={cat} onChange={(e) => setCat(e.target.value)} className="field mt-1"><option value="all">All</option>{categories.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}</select></div>}
        <div><label htmlFor="m" className="eyebrow">Max price (PKR)</label><select id="m" value={max} onChange={(e) => setMax(Number(e.target.value))} className="field mt-1"><option value={0}>Any</option><option value={10000}>10,000</option><option value={25000}>25,000</option><option value={50000}>50,000</option></select></div>
        <div><label htmlFor="s" className="eyebrow">Sort</label><select id="s" value={sort} onChange={(e) => setSort(e.target.value)} className="field mt-1"><option value="featured">Featured</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option></select></div>
      </div>
      <p className="mt-4 text-sm text-muted" role="status" aria-live="polite">{list.length} item{list.length === 1 ? "" : "s"}</p>
      {list.length === 0 ? <p className="mt-8 font-serif text-2xl">No pieces match. Try clearing a filter.</p> :
        <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">{list.map((p) => <ProductCard key={p.slug} p={p} />)}</div>}
    </div>
  );
}
