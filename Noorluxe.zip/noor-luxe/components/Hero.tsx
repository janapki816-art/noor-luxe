"use client";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

/** Expects /public/images/hero-model.jpg: licensed photo of an adult female model in a luxury outfit (portrait or square crop, model centred). */
export default function Hero() {
  const [bad, setBad] = useState(false);
  return (
    <section aria-label="Noor Luxe" className="relative flex h-[100svh] min-h-[620px] items-end overflow-hidden bg-[radial-gradient(ellipse_80%_55%_at_50%_38%,#2a2036_0%,#17121f_42%,#0A0A0B_80%)]">
      {!bad && <Image src="/images/hero-model.jpg" alt="Female model in an elegant designer gown, Noor Luxe campaign" fill priority sizes="100vw" onError={() => setBad(true)} className="object-cover object-[50%_20%]" />}
      <div aria-hidden="true" className="absolute inset-0 bg-[linear-gradient(to_top,rgba(10,10,11,.96)_0%,rgba(10,10,11,.7)_32%,rgba(10,10,11,.1)_62%,rgba(10,10,11,.45)_100%)] md:bg-[linear-gradient(to_right,rgba(10,10,11,.92)_0%,rgba(10,10,11,.55)_42%,transparent_72%)]" />
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 bottom-0 h-1/3 bg-[radial-gradient(ellipse_50%_80%_at_50%_100%,rgba(212,168,87,.28),transparent_70%)]" />
      <div className="relative z-10 w-full px-6 pb-[calc(env(safe-area-inset-bottom,0px)+88px)] md:max-w-3xl md:px-[8vw] md:pb-28">
        <span className="eyebrow rise block">The Art of Elegance</span>
        <h1 className="rise d2 my-4 font-serif text-[clamp(54px,16vw,132px)] font-normal leading-[.98] [text-shadow:0_4px_40px_rgba(0,0,0,.8)]">Elegance,<br /><em className="text-gold">Reimagined.</em></h1>
        <p className="rise d3 max-w-[34ch] text-[15px] text-ivory/80">Discover a world of timeless fashion, exquisite details, and modern luxury.</p>
        <div className="rise d4 mt-7 flex flex-col gap-3 sm:flex-row">
          <Link href="/shop" className="btn bg-gold !text-ink hover:bg-transparent hover:!text-gold">Explore Collection</Link>
          <Link href="/category/womens-fashion" className="btn">Discover the Edit</Link>
        </div>
      </div>
      <a href="#collections" aria-label="Scroll to collections" className="absolute bottom-[calc(env(safe-area-inset-bottom,0px)+16px)] left-1/2 z-10 -translate-x-1/2 text-center text-[9px] uppercase tracking-[.34em] text-gold">
        Scroll<span aria-hidden="true" className="mx-auto mt-2 block h-6 w-px bg-gradient-to-b from-gold to-transparent" />
      </a>
    </section>
  );
}
