"use client";
import { useShop } from "@/lib/shop";
export default function Price({ pkr }: { pkr: number }) { const { fmt } = useShop(); return <div className="text-lg tracking-wide text-gold">{fmt(pkr)}</div>; }
