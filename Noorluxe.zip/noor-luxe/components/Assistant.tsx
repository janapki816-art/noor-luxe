"use client";
import { useState } from "react";
import { useShop } from "@/lib/shop";
import { getProduct, variantLabel } from "@/lib/products";

type Reply = { text: string; picks: string[]; mode: "ai" | "fallback" };
export default function Assistant() {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [reply, setReply] = useState<Reply | null>(null);
  const { addToCart, fmt } = useShop();
  async function ask(e: React.FormEvent) {
    e.preventDefault(); if (!q.trim()) return; setBusy(true);
    try {
      const r = await fetch("/api/assistant", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: q }) });
      if (!r.ok) throw new Error("bad status");
      setReply((await r.json()) as Reply);
    } catch { setReply({ text: "The assistant is unavailable right now. You can still browse the Shop page and use search and filters.", picks: [], mode: "fallback" }); }
    setBusy(false);
  }
  return (
    <div className="fixed bottom-[calc(env(safe-area-inset-bottom,0px)+16px)] right-4 z-20">
      {!open ? <button className="btn bg-ink" onClick={() => setOpen(true)}>Ask Noor</button> : (
        <section aria-label="Shopping assistant" className="w-[min(92vw,360px)] border border-gold/40 bg-charcoal p-4 shadow-2xl">
          <div className="flex items-center justify-between"><span className="eyebrow">Noor · Shopping Assistant</span><button onClick={() => setOpen(false)} className="min-h-[44px] px-2 text-xs uppercase tracking-widest">Close</button></div>
          <form onSubmit={ask} className="mt-2 flex gap-2"><label className="sr-only" htmlFor="aq">Your question</label>
            <input id="aq" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Black shoes under 30,000" className="field" /><button className="btn px-4" disabled={busy}>{busy ? "…" : "Ask"}</button></form>
          {reply && <div className="mt-3 text-sm" role="status" aria-live="polite">
            <p>{reply.text}</p>
            {reply.mode === "fallback" && <p className="mt-1 text-xs text-muted">Basic matching (AI service not connected).</p>}
            <ul className="mt-2 space-y-2">{reply.picks.map((s) => { const p = getProduct(s); return p ? (
              <li key={s} className="flex items-center justify-between gap-2 border-t border-gold/20 pt-2"><span>{p.name}<br /><span className="text-gold">{fmt(p.pricePKR)}</span></span>
                <button className="btn px-3" onClick={() => addToCart(p.slug, variantLabel(p))} aria-label={`Confirm add ${p.name} to bag`}>Add</button></li>) : null; })}</ul>
          </div>}
        </section>)}
    </div>
  );
}
