"use client";
import Link from "next/link";
import { useState } from "react";
import { supabase } from "@/lib/supabase";

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const [email, setEmail] = useState(""); const [pw, setPw] = useState("");
  const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setMsg("");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return setMsg("Enter a valid email address.");
    if (pw.length < 8) return setMsg("Password must be at least 8 characters.");
    if (!supabase) return setMsg("Accounts are not connected yet. Add your Supabase keys to .env.local (see README).");
    setBusy(true);
    if (mode === "register") {
      const { error } = await supabase.auth.signUp({ email, password: pw, options: { emailRedirectTo: `${location.origin}/account` } });
      setMsg(error ? error.message : "Check your email to verify your address, then sign in.");
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password: pw });
      if (error) setMsg(error.message); else location.href = "/account";
    }
    setBusy(false);
  }
  async function reset() {
    if (!supabase) return setMsg("Accounts are not connected yet.");
    if (!email) return setMsg("Enter your email first.");
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${location.origin}/account` });
    setMsg(error ? error.message : "If that email exists, a reset link has been sent.");
  }
  return (
    <form onSubmit={submit} noValidate className="mx-auto max-w-sm space-y-4 px-6 pb-20 pt-28">
      <h1 className="font-serif text-5xl">{mode === "login" ? "Sign in" : "Create account"}</h1>
      <div><label htmlFor="e" className="eyebrow">Email</label><input id="e" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="field mt-1" /></div>
      <div><label htmlFor="p" className="eyebrow">Password</label><input id="p" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} value={pw} onChange={(e) => setPw(e.target.value)} className="field mt-1" /></div>
      <button className="btn w-full" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Sign in" : "Register"}</button>
      <p role="status" aria-live="polite" className="min-h-[22px] text-sm text-gold">{msg}</p>
      <div className="flex justify-between text-sm text-muted">
        {mode === "login" ? <><Link href="/register" className="py-2">Create account</Link><button type="button" onClick={reset} className="py-2">Forgot password?</button></> : <Link href="/login" className="py-2">Already registered? Sign in</Link>}
      </div>
    </form>
  );
}
