import Link from "next/link";
const items = [["about", "About"], ["contact", "Contact"], ["privacy", "Privacy"], ["terms", "Terms"], ["returns", "Returns"]];
export default function Footer() {
  return (
    <footer className="border-t border-gold/30 px-6 py-9 text-center text-[13px] text-muted">
      <div>{items.map(([s, l]) => <Link key={s} href={`/info/${s}`} className="mx-2.5 inline-block py-2">{l}</Link>)}</div>
      <div className="mt-3">© 2026 Noor Luxe</div>
    </footer>
  );
}
