"use client";
import Link from "next/link";
import { useShop } from "@/lib/shop";
import SafeImage from "./SafeImage";
import type { Product } from "@/lib/products";

export default function ProductCard({ p }: { p: Product }) {
  const { fmt, wishlist, toggleWish } = useShop();
  const wished = wishlist.includes(p.slug);
  return (
    <article className="group">
      <Link href={`/product/${p.slug}`} className="block">
        <div className="relative aspect-[4/5] overflow-hidden border border-gold/20 transition-colors group-hover:border-gold/60">
          <SafeImage src={p.images[0]} alt={p.name} sizes="(min-width:1024px) 25vw, 50vw" className="transition-transform duration-[1200ms] group-hover:scale-105" />
          {p.badge && <span className="absolute left-2 top-2 bg-ink/80 px-2 py-1 text-[10px] uppercase tracking-[.2em] text-gold">{p.badge}</span>}
        </div>
        <h3 className="mt-3 font-serif text-xl leading-tight">{p.name}</h3>
        <div className="text-xs text-muted">{p.brand}</div>
      </Link>
      <div className="flex items-center justify-between">
        <span className="text-sm tracking-wide text-gold">{fmt(p.pricePKR)}</span>
        <button onClick={() => toggleWish(p.slug)} aria-pressed={wished} aria-label={`${wished ? "Remove" : "Add"} ${p.name} ${wished ? "from" : "to"} wishlist`} className="min-h-[44px] min-w-[44px] text-lg text-gold">{wished ? "♥" : "♡"}</button>
      </div>
    </article>
  );
}
