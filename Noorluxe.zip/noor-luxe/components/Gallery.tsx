"use client";
import { useState } from "react";
import SafeImage from "./SafeImage";

export default function Gallery({ images, alt }: { images: string[]; alt: string }) {
  const [i, setI] = useState(0);
  return (
    <div>
      <div className="relative aspect-[4/5] overflow-hidden border border-gold/30"><SafeImage key={i} src={images[i]} alt={`${alt}, view ${i + 1}`} sizes="(min-width:768px) 50vw, 100vw" priority={i === 0} /></div>
      <div className="mt-3 grid grid-cols-3 gap-3">
        {images.map((s, n) => (
          <button key={s} onClick={() => setI(n)} aria-label={`Show view ${n + 1}`} aria-pressed={n === i} className={`relative aspect-square overflow-hidden border ${n === i ? "border-gold" : "border-gold/20"}`}>
            <SafeImage src={s} alt="" sizes="20vw" label={String(n + 1)} />
          </button>))}
      </div>
    </div>
  );
}
