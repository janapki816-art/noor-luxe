"use client";
import Link from "next/link";
import { useShop } from "@/lib/shop";
import { getProduct } from "@/lib/products";
import SafeImage from "@/components/SafeImage";
export default function Cart() {
  const { cart, setQty, fmt, cartTotalPKR } = useShop();
  return (
    <div className="mx-auto max-w-3xl px-6 pb-20 pt-28">
      <h1 className="mb-6 font-serif text-5xl">Your <em className="text-gold">bag</em></h1>
      {cart.length === 0 ? <div><p className="text-muted">Your bag is empty.</p><Link href="/shop" className="btn mt-5">Explore Collection</Link></div> : (
        <>
          <ul className="divide-y divide-gold/20">{cart.map((l) => { const p = getProduct(l.slug); if (!p) return null; return (
            <li key={l.slug + l.size} className="flex items-center justify-between gap-3 py-4"><div className="relative h-20 w-16 shrink-0 overflow-hidden border border-gold/20"><SafeImage src={p.images[0]} alt={p.name} sizes="64px" label="" /></div>
              <div><Link href={`/product/${p.slug}`} className="font-serif text-2xl">{p.name}</Link><div className="text-sm text-muted">{l.size} · {fmt(p.pricePKR)}</div></div>
              <div className="flex items-center gap-1">
                <button className="min-h-[44px] min-w-[44px] border border-gold/30" aria-label={`Decrease ${p.name}`} onClick={() => setQty(l.slug, l.size, l.qty - 1)}>−</button>
                <span className="w-8 text-center" aria-live="polite">{l.qty}</span>
                <button className="min-h-[44px] min-w-[44px] border border-gold/30" aria-label={`Increase ${p.name}`} disabled={l.qty >= p.stock} onClick={() => setQty(l.slug, l.size, l.qty + 1)}>+</button>
              </div></li>); })}</ul>
          <div className="mt-6 flex items-center justify-between border-t border-gold/30 pt-5"><span className="eyebrow">Subtotal</span><span className="font-serif text-3xl text-gold">{fmt(cartTotalPKR)}</span></div>
          <p className="mt-3 text-sm text-muted">Shipping and tax are calculated at checkout. Checkout and payment are not built yet.</p>
          <button className="btn mt-5" disabled>Checkout (coming soon)</button>
        </>)}
    </div>
  );
}
