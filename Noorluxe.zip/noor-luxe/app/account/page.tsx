"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
export default function Account() {
  const [email, setEmail] = useState<string | null | undefined>(undefined);
  useEffect(() => { if (!supabase) { setEmail(null); return; } supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? null)); }, []);
  async function out() { await supabase?.auth.signOut(); location.href = "/"; }
  return <div className="mx-auto max-w-xl px-6 pb-20 pt-28"><h1 className="mb-4 font-serif text-5xl">Account</h1>
    {email === undefined ? <p className="text-muted">Loading…</p> : email ? <><p>Signed in as <span className="text-gold">{email}</span></p><p className="mt-2 text-sm text-muted">Order history and addresses are not built yet.</p><button className="btn mt-5" onClick={out}>Sign out</button></> :
      <><p className="text-muted">You are not signed in{supabase ? "" : " (Supabase not configured)"}.</p><Link href="/login" className="btn mt-5">Sign in</Link></>}</div>;
}
