import Link from "next/link";
import Hero from "@/components/Hero";
import ProductCard from "@/components/ProductCard";
import SafeImage from "@/components/SafeImage";
import { categories, products } from "@/lib/products";

export default function Home() {
  return (
    <>
      <Hero />
      <section id="collections" className="mx-auto max-w-6xl px-6 py-20">
        <span className="eyebrow">Shop by world</span>
        <h2 className="mb-8 mt-3 font-serif text-[clamp(38px,9vw,68px)] font-normal leading-none">The <em className="text-gold">collections</em></h2>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {categories.map((c) => (
            <Link key={c.slug} href={`/category/${c.slug}`} className="group relative block aspect-[3/4] overflow-hidden border border-gold/30 transition-colors hover:border-gold">
              <SafeImage src={`/images/editorial/${c.slug}.jpg`} alt={`${c.name} collection`} sizes="(min-width:768px) 25vw, 50vw" className="transition-transform duration-[1200ms] group-hover:scale-105" label={c.name} />
              <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-ink/90 via-transparent to-transparent" />
              <span className="absolute bottom-3 left-3 right-3 font-serif text-xl leading-tight">{c.name}</span>
            </Link>
          ))}
        </div>
      </section>
      <section className="bg-charcoal px-6 py-20"><div className="mx-auto max-w-6xl">
        <span className="eyebrow">New &amp; bestselling · sample catalogue</span>
        <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">{products.filter((p) => p.badge).slice(0, 8).map((p) => <ProductCard key={p.slug} p={p} />)}</div>
      </div></section>
    </>
  );
}
