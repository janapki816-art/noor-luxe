import { notFound } from "next/navigation";
const pages: Record<string, [string, string]> = {
  about: ["About Noor Luxe", "Noor Luxe is a luxury house serving Pakistan, the UAE and Saudi Arabia. (Draft copy: replace with your brand story.)"],
  contact: ["Contact", "Contact details to be added. (Draft: no contact form is connected yet.)"],
  privacy: ["Privacy Policy", "DRAFT placeholder. Have a qualified professional write the real policy before launch."],
  terms: ["Terms & Conditions", "DRAFT placeholder. Have a qualified professional write the real terms before launch."],
  returns: ["Returns & Refunds", "DRAFT placeholder. Add your real returns and refund policy before launch."],
};
export function generateStaticParams() { return Object.keys(pages).map((slug) => ({ slug })); }
export default async function Info({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params; const pg = pages[slug]; if (!pg) notFound();
  return <div className="mx-auto max-w-2xl px-6 pb-20 pt-28"><h1 className="mb-4 font-serif text-5xl">{pg[0]}</h1><p className="text-muted">{pg[1]}</p></div>;
}
