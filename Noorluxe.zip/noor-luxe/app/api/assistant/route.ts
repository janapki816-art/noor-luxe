import { NextResponse } from "next/server";
import { categories, products, type Product } from "@/lib/products";

export const runtime = "nodejs";
const hits = new Map<string, { n: number; t: number }>();

function match(msg: string): Product[] {
  const m = msg.toLowerCase();
  const num = m.match(/(\d[\d,]*)/); const budget = num ? Number(num[1].replace(/,/g, "")) : 0;
  const words = m.split(/\W+/).filter((w) => w.length > 2);
  const cat = categories.find((c) => words.some((w) => c.slug.includes(w) || c.name.toLowerCase().includes(w)));
  return products.filter((p) => (!cat || p.category === cat.slug) && (!budget || p.pricePKR <= budget) &&
    (cat || words.some((w) => `${p.name} ${p.colors.join(" ")} ${p.description}`.toLowerCase().includes(w)) || budget > 0)).slice(0, 4);
}

export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for") ?? "local"; const now = Date.now();
  const h = hits.get(ip); if (h && now - h.t < 60000 && h.n >= 10) return NextResponse.json({ error: "rate" }, { status: 429 });
  hits.set(ip, h && now - h.t < 60000 ? { n: h.n + 1, t: h.t } : { n: 1, t: now });

  let message = ""; try { message = String((await req.json()).message ?? "").slice(0, 300); } catch { /* ignore */ }
  if (!message.trim()) return NextResponse.json({ error: "empty" }, { status: 400 });
  const picks = match(message);
  const base = { picks: picks.map((p) => p.slug) };
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return NextResponse.json({ ...base, mode: "fallback", text: picks.length ? "Here are matching pieces from our catalogue:" : "I could not find a match. Try a category or a budget." });
  try {
    const catalogue = (picks.length ? picks : products).map((p) => `${p.slug}: ${p.name}, ${p.pricePKR} PKR, ${p.colors.join("/")}, sizes ${p.sizes.join("/")}, stock ${p.stock}. ${p.description}`).join("\n");
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL ?? "claude-sonnet-4-6", max_tokens: 400,
        system: "You are Noor, a concise luxury shopping assistant. Answer ONLY using the catalogue below. Never invent products, prices or stock. Never claim to add items to the cart; the customer confirms with the Add button. Keep replies under 80 words.\nCATALOGUE:\n" + catalogue,
        messages: [{ role: "user", content: message }] }),
    });
    if (!r.ok) throw new Error(String(r.status));
    const data = (await r.json()) as { content: { type: string; text?: string }[] };
    return NextResponse.json({ ...base, mode: "ai", text: data.content.filter((c) => c.type === "text").map((c) => c.text).join(" ") });
  } catch {
    return NextResponse.json({ ...base, mode: "fallback", text: "The AI service is unavailable. Here are catalogue matches:" });
  }
}
