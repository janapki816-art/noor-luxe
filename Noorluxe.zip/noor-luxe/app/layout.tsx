import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Inter } from "next/font/google";
import "./globals.css";
import { ShopProvider } from "@/lib/shop";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Assistant from "@/components/Assistant";

const serif = Cormorant_Garamond({ subsets: ["latin"], weight: ["400", "500"], style: ["normal", "italic"], variable: "--font-serif" });
const sans = Inter({ subsets: ["latin"], variable: "--font-sans" });

export const metadata: Metadata = {
  title: { default: "Noor Luxe — Dressed in Light", template: "%s · Noor Luxe" },
  description: "Luxury fashion, shoes, watches, electronics and home for Pakistan, the UAE and Saudi Arabia.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, viewportFit: "cover", themeColor: "#0A0A0B" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${serif.variable} ${sans.variable}`}>
      <body className="font-sans antialiased">
        <ShopProvider>
          <Header />
          <main id="top">{children}</main>
          <Footer />
          <Assistant />
        </ShopProvider>
      </body>
    </html>
  );
}
