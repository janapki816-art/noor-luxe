import { notFound } from "next/navigation";
import AddToCart from "@/components/AddToCart";
import Gallery from "@/components/Gallery";
import Price from "@/components/Price";
import { getProduct, products } from "@/lib/products";

export function generateStaticParams() { return products.map((p) => ({ slug: p.slug })); }
export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = getProduct(slug);
  if (!p) notFound();
  return (
    <div className="mx-auto grid max-w-5xl gap-10 px-6 pb-20 pt-28 md:grid-cols-2">
      <Gallery images={p.images} alt={p.name} />
      <div>
        <span className="eyebrow">{p.badge ?? p.brand}</span>
        <h1 className="my-3 font-serif text-5xl font-normal leading-none">{p.name}</h1>
        <Price pkr={p.pricePKR} />
        <p className="mt-4 text-muted">{p.description}</p>
        <p className="mt-2 text-sm text-muted">{p.brand} · {p.stock > 0 ? `${p.stock} in stock (sample data)` : "Sold out"}</p>
        <AddToCart p={p} />
      </div>
    </div>
  );
}
