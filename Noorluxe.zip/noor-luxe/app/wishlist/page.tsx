"use client";
import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import { useShop } from "@/lib/shop";
import { products } from "@/lib/products";
export default function Wishlist() {
  const { wishlist } = useShop();
  const items = products.filter((p) => wishlist.includes(p.slug));
  return <div className="mx-auto max-w-6xl px-6 pb-20 pt-28"><h1 className="mb-6 font-serif text-5xl">Wish<em className="text-gold">list</em></h1>
    {items.length === 0 ? <div><p className="text-muted">Nothing saved yet.</p><Link href="/shop" className="btn mt-5">Browse the shop</Link></div> :
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">{items.map((p) => <ProductCard key={p.slug} p={p} />)}</div>}</div>;
}
