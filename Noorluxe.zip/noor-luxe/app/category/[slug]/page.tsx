import { notFound } from "next/navigation";
import ProductBrowser from "@/components/ProductBrowser";
import { categories, products } from "@/lib/products";
export function generateStaticParams() { return categories.map((c) => ({ slug: c.slug })); }
export default async function Category({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const cat = categories.find((c) => c.slug === slug);
  if (!cat) notFound();
  return <div className="mx-auto max-w-6xl px-6 pb-20 pt-28"><span className="eyebrow">Collection</span><h1 className="mb-6 font-serif text-5xl">{cat.name}</h1>
    <ProductBrowser items={products.filter((p) => p.category === slug)} lockCategory /></div>;
}
