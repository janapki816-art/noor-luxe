import type { Metadata } from "next";
import ProductBrowser from "@/components/ProductBrowser";
import { products } from "@/lib/products";
export const metadata: Metadata = { title: "Shop All" };
export default async function Shop({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  return <div className="mx-auto max-w-6xl px-6 pb-20 pt-28"><h1 className="mb-6 font-serif text-5xl font-normal">Shop <em className="text-gold">all</em></h1><ProductBrowser items={products} initialQuery={q ?? ""} /></div>;
}
