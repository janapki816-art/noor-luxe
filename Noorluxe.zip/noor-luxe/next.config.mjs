/** Local images in /public only (no remote domains needed). Add `images.remotePatterns` if you later use Supabase Storage. */
const nextConfig = { reactStrictMode: true, images: { formats: ["image/avif", "image/webp"] } };
export default nextConfig;
