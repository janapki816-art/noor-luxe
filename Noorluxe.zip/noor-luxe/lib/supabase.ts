import { createClient } from "@supabase/supabase-js";
const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
/** null until env vars are set, so the site still runs without Supabase. */
export const supabase = url && key ? createClient(url, key) : null;
