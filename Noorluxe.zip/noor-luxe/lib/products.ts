export type Category = { slug: string; name: string };
export type Product = {
  slug: string; name: string; brand: string; category: string; pricePKR: number;
  colors: string[]; sizes: string[]; description: string; stock: number; badge?: "New" | "Bestseller";
  images: string[]; sample: true;
};
export const categories: Category[] = [
  { slug: "womens-fashion", name: "Women" }, { slug: "mens-fashion", name: "Men" },
  { slug: "shoes", name: "Shoes" }, { slug: "bags-accessories", name: "Bags & Accessories" },
  { slug: "watches-jewellery", name: "Watches & Jewellery" }, { slug: "beauty-lifestyle", name: "Beauty & Lifestyle" },
  { slug: "electronics", name: "Electronics" }, { slug: "home-living", name: "Home & Living" },
];
/* SAMPLE CATALOGUE for development. Prices and stock are NOT live inventory.
   Brand is "Noor Luxe Selection" because no third-party brand has been verified.
   Images are expected at /public/images/products/<slug>-1.jpg, -2.jpg, -3.jpg (see public/images/README.md).
   Missing files show a graceful fallback tile. */
const imgs = (slug: string) => [1, 2, 3].map((n) => `/images/products/${slug}-${n}.jpg`);
const B = "Noor Luxe Selection";
type Seed = Omit<Product, "images" | "sample" | "brand"> & { brand?: string };
const mk = (s: Seed): Product => ({ brand: B, ...s, images: imgs(s.slug), sample: true });
const S5 = ["XS", "S", "M", "L", "XL"], SH = ["40", "41", "42", "43", "44"], ONE = ["One size"];
export const products: Product[] = [
  mk({ slug: "silk-evening-gown", name: "Silk Evening Gown", category: "womens-fashion", pricePKR: 58000, colors: ["Black", "Ivory"], sizes: S5, description: "Floor-length silk gown with an open back and fluid drape.", stock: 5, badge: "New" }),
  mk({ slug: "satin-wrap-dress", name: "Satin Wrap Dress", category: "womens-fashion", pricePKR: 34000, colors: ["Champagne", "Black"], sizes: S5, description: "Midi wrap dress in heavy satin with a tie waist.", stock: 12, badge: "Bestseller" }),
  mk({ slug: "embroidered-shawl", name: "Gold Embroidered Shawl", category: "womens-fashion", pricePKR: 21000, colors: ["Gold", "Ivory"], sizes: ONE, description: "Wool-silk shawl with hand-finished embroidery.", stock: 12 }),
  mk({ slug: "charcoal-wool-suit", name: "Charcoal Wool Suit", category: "mens-fashion", pricePKR: 42000, colors: ["Charcoal", "Navy"], sizes: ["46", "48", "50", "52"], description: "Two-piece suit in fine wool with a half-canvas build.", stock: 8, badge: "Bestseller" }),
  mk({ slug: "ivory-cotton-shirt", name: "Ivory Cotton Shirt", category: "mens-fashion", pricePKR: 9500, colors: ["Ivory", "Sky"], sizes: ["S", "M", "L", "XL"], description: "Pure cotton shirt with mother-of-pearl buttons.", stock: 25 }),
  mk({ slug: "calfskin-oxford", name: "Calfskin Oxford", category: "shoes", pricePKR: 26000, colors: ["Black", "Brown"], sizes: SH, description: "Goodyear-welted oxford in polished calfskin.", stock: 14 }),
  mk({ slug: "leather-sneaker", name: "Minimal Leather Sneaker", category: "shoes", pricePKR: 18500, colors: ["White", "Black"], sizes: SH, description: "Clean low-top sneaker in smooth leather.", stock: 20, badge: "New" }),
  mk({ slug: "structured-handbag", name: "Structured Leather Handbag", category: "bags-accessories", pricePKR: 46000, colors: ["Black", "Tan"], sizes: ONE, description: "Top-handle bag in grained leather with a suede lining.", stock: 6, badge: "Bestseller" }),
  mk({ slug: "leather-cardholder", name: "Leather Card Holder", category: "bags-accessories", pricePKR: 7500, colors: ["Black", "Burgundy"], sizes: ONE, description: "Slim card holder with edge-painted leather.", stock: 40 }),
  mk({ slug: "gold-chronograph", name: "Gold-Tone Chronograph", category: "watches-jewellery", pricePKR: 95000, colors: ["Gold"], sizes: ONE, description: "Automatic chronograph in a gold-tone steel case.", stock: 3, badge: "New" }),
  mk({ slug: "pearl-drop-earrings", name: "Pearl Drop Earrings", category: "watches-jewellery", pricePKR: 15500, colors: ["Gold", "Silver"], sizes: ONE, description: "Freshwater-pearl drops on hypoallergenic posts.", stock: 22 }),
  mk({ slug: "amber-candle-set", name: "Amber Candle Set", category: "beauty-lifestyle", pricePKR: 6800, colors: ["Amber"], sizes: ONE, description: "Three hand-poured candles in smoked glass.", stock: 30 }),
  mk({ slug: "oud-eau-de-parfum", name: "Oud Eau de Parfum", category: "beauty-lifestyle", pricePKR: 17500, colors: ["Amber"], sizes: ["50 ml", "100 ml"], description: "Warm oud and amber fragrance.", stock: 15, badge: "Bestseller" }),
  mk({ slug: "noise-cancelling-headphones", name: "Noise-Cancelling Headphones", category: "electronics", pricePKR: 48000, colors: ["Black", "Silver"], sizes: ONE, description: "Over-ear wireless headphones with a 30-hour battery.", stock: 18 }),
  mk({ slug: "velvet-throw", name: "Velvet Throw", category: "home-living", pricePKR: 14500, colors: ["Violet", "Charcoal"], sizes: ONE, description: "Heavy velvet throw with a satin reverse.", stock: 16 }),
  mk({ slug: "marble-tray", name: "Marble Serving Tray", category: "home-living", pricePKR: 11200, colors: ["White", "Black"], sizes: ONE, description: "Polished marble tray with brass handles.", stock: 10, badge: "New" }),
];
export const getProduct = (slug: string) => products.find((p) => p.slug === slug);
export const variantLabel = (p: Product, color = p.colors[0], size = p.sizes[0]) => `${color} / ${size}`;
