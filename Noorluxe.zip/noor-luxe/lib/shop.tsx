"use client";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { getProduct } from "./products";

export type Currency = "PKR" | "AED" | "SAR";
// Display-only rates (placeholder). Use a real rates source before charging customers.
const RATE: Record<Currency, number> = { PKR: 1, AED: 0.013, SAR: 0.0134 };
export type CartLine = { slug: string; size: string; qty: number };

type Ctx = {
  currency: Currency; setCurrency: (c: Currency) => void; fmt: (pkr: number) => string;
  cart: CartLine[]; addToCart: (slug: string, size: string) => void;
  setQty: (slug: string, size: string, qty: number) => void; cartCount: number; cartTotalPKR: number;
  wishlist: string[]; toggleWish: (slug: string) => void;
};
const ShopCtx = createContext<Ctx | null>(null);

function load<T>(key: string, fallback: T): T {
  try { const v = localStorage.getItem(key); return v ? (JSON.parse(v) as T) : fallback; } catch { return fallback; }
}
function save(key: string, v: unknown) { try { localStorage.setItem(key, JSON.stringify(v)); } catch { /* storage unavailable */ } }

export function ShopProvider({ children }: { children: ReactNode }) {
  const [currency, setCurrency] = useState<Currency>("PKR");
  const [cart, setCart] = useState<CartLine[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [ready, setReady] = useState(false);
  useEffect(() => { setCurrency(load("nl-cur", "PKR")); setCart(load("nl-cart", [])); setWishlist(load("nl-wish", [])); setReady(true); }, []);
  useEffect(() => { if (ready) { save("nl-cur", currency); save("nl-cart", cart); save("nl-wish", wishlist); } }, [currency, cart, wishlist, ready]);

  const fmt = (pkr: number) => `${currency} ${Math.round(pkr * RATE[currency]).toLocaleString("en-US")}`;
  const addToCart = (slug: string, size: string) => {
    const p = getProduct(slug); if (!p) return;
    setCart((c) => {
      const i = c.findIndex((l) => l.slug === slug && l.size === size);
      if (i < 0) return [...c, { slug, size, qty: 1 }];
      return c.map((l, j) => (j === i ? { ...l, qty: Math.min(l.qty + 1, p.stock) } : l));
    });
  };
  const setQty = (slug: string, size: string, qty: number) =>
    setCart((c) => c.map((l) => (l.slug === slug && l.size === size ? { ...l, qty } : l)).filter((l) => l.qty > 0));
  const toggleWish = (slug: string) => setWishlist((w) => (w.includes(slug) ? w.filter((s) => s !== slug) : [...w, slug]));
  const cartCount = cart.reduce((n, l) => n + l.qty, 0);
  const cartTotalPKR = cart.reduce((n, l) => n + (getProduct(l.slug)?.pricePKR ?? 0) * l.qty, 0);
  return <ShopCtx.Provider value={{ currency, setCurrency, fmt, cart, addToCart, setQty, cartCount, cartTotalPKR, wishlist, toggleWish }}>{children}</ShopCtx.Provider>;
}
export function useShop() { const c = useContext(ShopCtx); if (!c) throw new Error("useShop outside ShopProvider"); return c; }
